"""
Module used to manipulate schemas.
"""

__all__ = ["Schema"]

from .crud_schema import Schema
